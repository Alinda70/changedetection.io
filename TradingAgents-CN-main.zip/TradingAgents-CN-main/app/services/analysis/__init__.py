"""Analysis service subpackage.

This package contains utilities split out from the monolithic analysis_service.py
without changing the public API of AnalysisService.
"""

