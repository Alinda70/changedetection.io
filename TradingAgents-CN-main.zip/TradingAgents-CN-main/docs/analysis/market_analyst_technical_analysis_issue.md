# 市场分析师技术分析问题诊断报告

## 📋 问题描述

用户反馈：市场分析师做的技术分析不准确。

## 🔍 问题根源

经过代码审查，发现了关键问题：

### 1. 美股数据 ✅ 有技术指标

**文件**: `tradingagents/dataflows/providers/us/optimized.py`

**代码位置**: 第 221-252 行

```python
# 计算技术指标
data['MA5'] = data['Close'].rolling(window=5).mean()
data['MA10'] = data['Close'].rolling(window=10).mean()
data['MA20'] = data['Close'].rolling(window=20).mean()

# 计算RSI
delta = data['Close'].diff()
gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
rs = gain / loss
rsi = 100 - (100 / (1 + rs))

# 格式化输出
result = f"""# {symbol} 美股数据分析

## 🔍 技术指标
- MA5: ${data['MA5'].iloc[-1]:.2f}
- MA10: ${data['MA10'].iloc[-1]:.2f}
- MA20: ${data['MA20'].iloc[-1]:.2f}
- RSI: {rsi.iloc[-1]:.2f}
```

**结论**: ✅ 美股数据包含完整的技术指标计算

---

### 2. 中国A股数据 ❌ 没有技术指标

**文件**: `tradingagents/dataflows/data_source_manager.py`

**代码位置**: 第 634-685 行

```python
def _format_stock_data_response(self, data: pd.DataFrame, symbol: str, stock_name: str,
                                start_date: str, end_date: str) -> str:
    """格式化股票数据响应"""
    try:
        # 🔧 优化：只保留最后3天的数据，减少token消耗
        if len(data) > 3:
            data = data.tail(3)

        # 计算最新价格和涨跌幅
        latest_data = data.iloc[-1]
        latest_price = latest_data.get('close', 0)
        prev_close = data.iloc[-2].get('close', latest_price) if len(data) > 1 else latest_price
        change = latest_price - prev_close
        change_pct = (change / prev_close * 100) if prev_close != 0 else 0

        # 格式化数据报告
        result = f"📊 {stock_name}({symbol}) - 数据\n"
        result += f"数据期间: {start_date} 至 {end_date}\n"
        result += f"数据条数: {len(data)}条 (最近{len(data)}个交易日)\n\n"

        result += f"💰 最新价格: ¥{latest_price:.2f}\n"
        result += f"📈 涨跌额: {change:+.2f} ({change_pct:+.2f}%)\n\n"

        # 添加统计信息（基于保留的数据）
        result += f"📊 价格统计 (最近{len(data)}个交易日):\n"
        result += f"   最高价: ¥{data['high'].max():.2f}\n"
        result += f"   最低价: ¥{data['low'].min():.2f}\n"
        result += f"   平均价: ¥{data['close'].mean():.2f}\n"
        volume_value = self._get_volume_safely(data)
        result += f"   成交量: {volume_value:,.0f}股\n"

        return result
```

**问题**:
- ❌ **没有计算任何技术指标**（MA, RSI, MACD, BOLL等）
- ❌ 只返回基本价格信息：最新价格、涨跌幅、最高价、最低价、平均价、成交量
- ❌ 大模型无法基于技术指标进行专业分析，只能"猜测"

---

## 🎯 影响范围

### 受影响的市场
- ❌ **中国A股**：没有技术指标
- ❌ **港股**：可能也没有技术指标（需要进一步确认）
- ✅ **美股**：有技术指标

### 受影响的分析师
- ❌ **市场分析师** (`market_analyst.py`)：依赖技术指标进行分析
- ❌ **中国市场分析师** (`china_market_analyst.py`)：专门分析A股，更依赖技术指标

---

## 💡 解决方案

### 方案1: 在数据源层面添加技术指标计算（推荐）⭐

**优点**:
- ✅ 统一所有市场的数据格式
- ✅ 技术指标计算准确、专业
- ✅ 减少大模型的推理负担
- ✅ 提高分析准确性

**实施步骤**:

1. **修改 `data_source_manager.py` 的 `_format_stock_data_response()` 函数**
   - 添加技术指标计算（参考美股实现）
   - 包括：MA5, MA10, MA20, MA60, RSI, MACD, BOLL

2. **使用统一的技术指标计算库**
   - 使用 `tradingagents/tools/analysis/indicators.py`
   - 或使用 `stockstats` 库（已有依赖）

3. **确保数据量足够**
   - 当前只保留最后3天数据（第655行）
   - 技术指标计算需要更多历史数据（至少60天）
   - 建议：获取60天数据用于计算，但只返回最后3-5天的指标值

---

### 方案2: 让大模型调用技术指标工具

**优点**:
- ✅ 灵活性高，大模型可以按需获取指标
- ✅ 减少初始数据量

**缺点**:
- ❌ 增加工具调用次数
- ❌ 增加延迟
- ❌ 大模型可能忘记调用工具
- ❌ 工具调用可能失败

**实施步骤**:
1. 确保 `get_stockstats_indicators_report` 工具可用
2. 在市场分析师的提示词中强调必须调用技术指标工具
3. 处理工具调用失败的情况

---

## 📊 技术指标对比

| 指标类型 | 美股 | A股 | 说明 |
|---------|------|-----|------|
| **移动平均线** | ✅ MA5, MA10, MA20 | ❌ 无 | 趋势判断的基础指标 |
| **RSI** | ✅ 14日RSI | ❌ 无 | 超买超卖判断 |
| **MACD** | ❌ 无 | ❌ 无 | 趋势强度和转折点 |
| **布林带** | ❌ 无 | ❌ 无 | 波动率和支撑压力 |
| **KDJ** | ❌ 无 | ❌ 无 | 中国市场常用指标 |

---

## 🔧 推荐实施方案

### 第一阶段：快速修复（1-2小时）

1. **修改 `data_source_manager.py`**
   - 在 `_format_stock_data_response()` 中添加基础技术指标计算
   - 参考美股实现，添加 MA5, MA10, MA20, RSI

2. **调整数据获取策略**
   - 获取60天数据用于指标计算
   - 只返回最后3-5天的指标值给大模型

3. **测试验证**
   - 测试A股技术分析准确性
   - 对比修复前后的分析质量

### 第二阶段：完善优化（2-4小时）

1. **添加更多技术指标**
   - MACD (DIF, DEA, MACD柱)
   - 布林带 (上轨, 中轨, 下轨)
   - KDJ (K, D, J)
   - ATR (平均真实波幅)

2. **统一技术指标计算**
   - 使用 `tradingagents/tools/analysis/indicators.py`
   - 确保所有市场使用相同的计算方法

3. **优化数据格式**
   - 统一美股和A股的数据输出格式
   - 添加技术指标的解读说明

### 第三阶段：港股支持（1-2小时）

1. **检查港股数据格式化**
   - 确认是否有技术指标
   - 如果没有，参考A股修复方案

2. **统一三个市场的数据格式**
   - A股、港股、美股使用相同的技术指标
   - 统一的数据输出格式

---

## 📝 代码示例

### 修复后的 A股数据格式化函数（示例）

```python
def _format_stock_data_response(self, data: pd.DataFrame, symbol: str, stock_name: str,
                                start_date: str, end_date: str) -> str:
    """格式化股票数据响应（包含技术指标）"""
    try:
        # 🔧 计算技术指标需要足够的历史数据
        # 但只返回最后3-5天的数据给大模型
        
        # 计算技术指标（使用完整数据）
        data['ma5'] = data['close'].rolling(window=5).mean()
        data['ma10'] = data['close'].rolling(window=10).mean()
        data['ma20'] = data['close'].rolling(window=20).mean()
        data['ma60'] = data['close'].rolling(window=60).mean()
        
        # 计算RSI
        delta = data['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        data['rsi'] = 100 - (100 / (1 + rs))
        
        # 计算MACD
        ema12 = data['close'].ewm(span=12, adjust=False).mean()
        ema26 = data['close'].ewm(span=26, adjust=False).mean()
        data['macd_dif'] = ema12 - ema26
        data['macd_dea'] = data['macd_dif'].ewm(span=9, adjust=False).mean()
        data['macd'] = (data['macd_dif'] - data['macd_dea']) * 2
        
        # 计算布林带
        data['boll_mid'] = data['close'].rolling(window=20).mean()
        std = data['close'].rolling(window=20).std()
        data['boll_upper'] = data['boll_mid'] + 2 * std
        data['boll_lower'] = data['boll_mid'] - 2 * std
        
        # 只保留最后3-5天的数据用于展示
        display_data = data.tail(3)
        latest_data = data.iloc[-1]
        
        # 格式化输出
        result = f"📊 {stock_name}({symbol}) - 技术分析数据\n"
        result += f"数据期间: {start_date} 至 {end_date}\n\n"
        
        result += f"💰 最新价格: ¥{latest_data['close']:.2f}\n"
        result += f"📈 涨跌幅: {((latest_data['close'] - data.iloc[-2]['close']) / data.iloc[-2]['close'] * 100):+.2f}%\n\n"
        
        result += f"📊 移动平均线:\n"
        result += f"   MA5:  ¥{latest_data['ma5']:.2f}\n"
        result += f"   MA10: ¥{latest_data['ma10']:.2f}\n"
        result += f"   MA20: ¥{latest_data['ma20']:.2f}\n"
        result += f"   MA60: ¥{latest_data['ma60']:.2f}\n\n"
        
        result += f"📈 MACD指标:\n"
        result += f"   DIF:  {latest_data['macd_dif']:.2f}\n"
        result += f"   DEA:  {latest_data['macd_dea']:.2f}\n"
        result += f"   MACD: {latest_data['macd']:.2f}\n\n"
        
        result += f"📉 RSI指标: {latest_data['rsi']:.2f}\n\n"
        
        result += f"📊 布林带:\n"
        result += f"   上轨: ¥{latest_data['boll_upper']:.2f}\n"
        result += f"   中轨: ¥{latest_data['boll_mid']:.2f}\n"
        result += f"   下轨: ¥{latest_data['boll_lower']:.2f}\n\n"
        
        result += f"📋 最近{len(display_data)}日数据:\n"
        result += display_data[['date', 'open', 'high', 'low', 'close', 'volume']].to_string()
        
        return result
        
    except Exception as e:
        logger.error(f"❌ 格式化数据响应失败: {e}")
        return f"❌ 格式化{symbol}数据失败: {e}"
```

---

## ✅ 预期效果

修复后，市场分析师将能够：

1. **基于真实技术指标进行分析**
   - 不再是"猜测"，而是基于计算出的MA、RSI、MACD等指标
   
2. **提供更准确的趋势判断**
   - 均线多头/空头排列
   - MACD金叉/死叉
   - RSI超买/超卖

3. **给出更专业的投资建议**
   - 支撑位/压力位判断
   - 买入/卖出信号
   - 风险提示

---

## 📌 总结

**问题根源**: A股数据没有提供技术指标，大模型只能基于简单价格信息进行"猜测"

**解决方案**: 在数据源层面添加技术指标计算，确保大模型收到完整的技术分析数据

**优先级**: 🔴 高优先级 - 直接影响核心功能的准确性

**预计工作量**: 
- 快速修复：1-2小时
- 完善优化：2-4小时
- 港股支持：1-2小时
- **总计：4-8小时**

